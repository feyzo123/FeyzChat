function startChat(username, room, isNokia=false) {
    const socket = io();

    socket.emit("join", {username, room});

    const form = document.getElementById("chat-form");
    const input = document.getElementById("message");
    const messages = document.getElementById("messages");
    const typingDiv = document.getElementById("typing");

    form.addEventListener("submit", (e) => {
        e.preventDefault();
        if (input.value) {
            socket.emit("text", {msg: input.value});
            input.value = "";
        }
    });

    input.addEventListener("input", () => {
        socket.emit("typing", {});
    });

    socket.on("message", (data) => {
        const div = document.createElement("div");
        div.className = data.username === username ? "mine" : "other";
        div.innerText = data.username + ": " + data.msg;
        messages.appendChild(div);
        messages.scrollTop = messages.scrollHeight;
    });

    socket.on("status", (data) => {
        const div = document.createElement("div");
        div.className = "status";
        div.innerText = data.msg;
        messages.appendChild(div);
    });

    socket.on("typing", (data) => {
        typingDiv.innerText = data.username + " yazıyor...";
        setTimeout(() => typingDiv.innerText = "", 2000);
    });

    window.loadMore = () => {
        alert("⬆ Daha eski mesaj yükleme özelliği sonra eklenecek.");
    }
}